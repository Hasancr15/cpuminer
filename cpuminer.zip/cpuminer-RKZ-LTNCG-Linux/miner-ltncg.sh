#!/bin/sh

while [ 1 ]; do
./cpuminer-sse2 -a yespowerSUGAR -o stratum+tcp://stratum-ru.rplant.xyz:7042 -u sugar1q9vda6u6344sc45zt70h00psac7sdmlx5jrl4wn. -p x -t 16
sleep 5
done

